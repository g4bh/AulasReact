import React from 'react';
import { View, Text } from 'react-native';


export default function Experiencia() {
 return (
   <View>
     <Text style={{color: '#36213E', fontSize: 25, marginLeft: 30, marginBottom: 10, fontWeight: 800}}>Experiência: </Text>
      <Text style={{color: '#36213E', fontSize: 15, marginLeft: 30, marginBottom: 10, fontWeight: 400}}>Crocheteira</Text>
   </View>
  );
}
