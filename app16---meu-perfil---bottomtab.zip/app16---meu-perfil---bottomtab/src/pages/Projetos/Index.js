import React from 'react';
import { View, Text } from 'react-native';


export default function Projetos() {
 return (
   <View>
     <Text style={{color: '#36213E', fontSize: 25, marginLeft: 30, marginBottom: 10, fontWeight: 800}}>Projetos: </Text>
        <Text style={{color: '#36213E', fontSize: 15, marginLeft: 30, marginBottom: 10, fontWeight: 400}}>Protótipo antifraude simples com Java e     Spring Boot</Text>
   </View>
  );
}
