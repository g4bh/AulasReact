import React from 'react';
import { View, Text } from 'react-native';


export default function Formacao() {
 return (
   <View>
     <Text style={{color: '#36213E', fontSize: 25, marginLeft: 30, marginBottom: 10, fontWeight: 800}}>Formação: </Text>
      <Text style={{color: '#36213E', fontSize: 15, marginLeft: 30, marginBottom: 10, fontWeight: 400}}>Sistemas para Internet</Text>
   </View>
  );
}
