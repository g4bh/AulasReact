import { View, Text, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Icon from 'react-native-vector-icons/Ionicons';

import myImage from './assets/pingupingu.png';

import Dados from './src/pages/Dados/Index';
import Experiencia from './src/pages/Experiencia/Index';
import Formacao from './src/pages/Formacao/Index';
import Projetos from './src/pages/Projetos/Index'

const Tab = createBottomTabNavigator();

const icons = {
  Dados:{
    name: 'people-outline',
  },
  Experiencia:{
    name: 'ribbon-outline',
  },
  Formacao:{
    name: 'school-outline',
  },
  Projetos:{
    name: 'folder-outline',
  }
}


function App(){
    let nome = 'Gabriella';

  return(
     <NavigationContainer>
      <Tab.Navigator 
      screenOptions={ ({route}) => ({
        tabBarIcon: ({ color, size }) => {
          const { name } = icons[route.name];
          return <Icon name={name} color={color} size={size} />
        }
      }) }
      >
        <Tab.Screen name='Dados' component={Dados} />
        <Tab.Screen name='Experiencia' component={Experiencia} />
        <Tab.Screen name='Formacao' component={Formacao} />
        <Tab.Screen name='Projetos' component={Projetos} />
      </Tab.Navigator>
    </NavigationContainer>

  )
}




export default App;