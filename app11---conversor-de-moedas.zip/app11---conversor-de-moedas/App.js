import {View, Text} from 'react-native';

import Conversor from './src/pages/conversor/index';

import Header from './src/components/header/index';

function App(){

return (
  <View>

    <Header />

    <Conversor />
  </View>
)

}

export default App;