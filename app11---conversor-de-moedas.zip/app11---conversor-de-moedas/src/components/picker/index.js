import { View, Button, Picker } from 'react-native'
import {styles} from './styles'

const Caixinha = ({ selectedValue, onValueChange }) => {
  return (
    <View>
      <Picker
        style={styles.picker}
        selectedValue={selectedValue}
        onValueChange={(itemValue) => onValueChange(itemValue)}
      >
        <Picker.Item key={0} value="" label="Selecione a moeda final" />
        <Picker.Item key={1} value="Real" label="Real" />
        <Picker.Item key={2} value="Dolar" label="Dólar" />
        <Picker.Item key={3} value="Euro" label="Euro" />
      </Picker>
    </View>
  );
};

export default Caixinha