import { View, Text, Image } from 'react-native'

import imagemMoedaKawaii from '../../../assets/moedas-kawaii.jpeg'

import {styles} from './styles'

function Header(){
  return(
      <View style={styles.container}>
        <Text style={styles.titulo}>Conversor de Moeda 💴</Text>
        <Image source={ imagemMoedaKawaii } style={styles.imagem}/>
      </View>
  )
}

export default Header