import  React, { useState } from 'react'
import { View, Text, TextInput, Button, SafeAreaView, Image } from 'react-native'
import {Picker} from '@react-native-picker/picker';

import {styles} from './styles'

import Input from '../../components/input/index'
import Botao from '../../components/botao/index'
import Caixinha from '../../components/picker/index'

function Conversor(){

  const [valor, setValor] = useState(0)
  const [moeda1, setMoeda1] = useState('')
  const [moeda2, setMoeda2] = useState('')
  const [resultado, setResultado] = useState()

  function calcular(){

  let exibe;
  if (moeda1 === 'Real') {
    if (moeda2 === 'Dolar') {
      exibe = valor * 0.2
    } else if (moeda2 === 'Euro') {
      exibe = valor * 0.185
    } else {
      exibe = valor * 1
    }
  } else if (moeda1 === 'Dolar') {
    if (moeda2 === 'Real') {
      exibe = valor * 5
    } else if (moeda2 === 'Euro') {
      exibe = valor * 0.92
    } else {
      exibe = valor * 1  
    }
  } else if (moeda1 === 'Euro') {
    if (moeda2 === 'Real') {
      exibe = valor * 5.4  
    } else if (moeda2 === 'Dolar') {
      exibe = valor * 1.08  
    } else {
      exibe = valor * 1  
    }
  } else {
    exibe = valor * 1 
  }
  setResultado(exibe.toFixed(2))
   
  }

return(
    <SafeAreaView>

      <View style={styles.area}>
        
        
        <Input
          placeholder = 'Digite o valor para converter'
          funcao = {setValor}
          tipo = 'decimal-pad'
        /> 


      <Caixinha 
        selectedValue = {moeda1}
        onValueChange = {setMoeda1}
      />
      
      <Caixinha 
        selectedValue = {moeda2}
        onValueChange = {setMoeda2}
      />


        <Botao 
          titulo = 'Calcular'
          cor = '#FFB30F'
          funcao = {calcular}
        />


        <Text style={styles.resultado}>Resultado: {resultado}</Text>

        </View>
    </SafeAreaView>
  )

}

export default Conversor