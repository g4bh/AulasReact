import {View, Text, Image} from 'react-native';
import {styles} from './Styles';

export default function Detalhe( {route} ) {

const { img, descricaoProduto } = route.params; 

  return (
    <View style={styles.areaDadosExibidos}>
    <View style={styles.dadosExibidos}>
          <Text style={ styles.tituloCard }>Dados - Carro</Text>
          <Image source={{ uri: img }} style={styles.imagemProduto} />
          <Text style={styles.descricaoCard}>{descricaoProduto}</Text>
        </View>
      </View>
  );
}