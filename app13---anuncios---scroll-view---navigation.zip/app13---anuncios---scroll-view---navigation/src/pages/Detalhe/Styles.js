import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  container: {
    padding: 10,
    marginHorizontal: 'auto',
    backgroundColor:'#2E547F',
    height: '100%'
  },
  imagemProduto: {
    alignSelf: 'center',
    width: '100%', 
    height: 150,
    borderRadius: 10,
  },
  tituloCard: {
    fontSize: 25,
    fontWeight: '500',
    padding: 10
  },
  precoCard: {
    fontSize: 18,
    fontWeight: '500',
    padding: 10
  },
  descricaoCard: {
    fontSize: 25,
    fontWeight: '300',
    padding: 10
  },
  areaDadosExibidos:
  {
    padding: 30,
    backgroundColor: '#2E547F'
  },
  dadosExibidos: {
    marginTop: 10,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 15
  }
});

export {styles}