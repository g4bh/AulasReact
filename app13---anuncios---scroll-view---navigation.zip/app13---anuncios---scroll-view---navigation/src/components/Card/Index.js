import { View, StyleSheet, FlatList, Text, Button, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';


import {styles} from './Styles'


export default function Card(props){

  const navigation = useNavigation();

  function irDetalhes(){
      navigation.navigate('Detalhes', { img: props.imagemProduto, descricaoProduto: props.descricaoProduto });
  }

return(
    <View style={styles.card}>
      <View> 
        <Image source={{uri: props.imagemProduto}} style={styles.imagemProduto} />
        <Text style={styles.tituloCard}> {props.nomeProduto} </Text>
        <Text style={styles.precoCard}> {props.preco} </Text>
        <Text style={{display: 'none'}}> {props.descricaoProduto} </Text>
        <Button title="Detalhes" onPress={irDetalhes} color='#000'/>
      </View>
    </View>

  );


}
