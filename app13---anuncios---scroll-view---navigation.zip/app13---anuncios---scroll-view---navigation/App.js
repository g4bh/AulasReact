import {  View, ScrollView } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import  Anuncios  from './src/pages/Anuncio/Index';
import  Detalhe  from './src/pages/Detalhe/Index';


const Stack = createStackNavigator();

export default function App(){

return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Anuncios" component={Anuncios} options={{headerShown: false }}/>
        <Stack.Screen name="Detalhes" component={Detalhe} />
      </Stack.Navigator>
    </NavigationContainer>
  );

}
