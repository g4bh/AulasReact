import { View, StyleSheet, FlatList, Text, Button, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';


import {styles} from './Styles'


function Card(props){

  const navigation = useNavigation();

  function irDetalhes(){
      navigation.navigate('Detalhes', { nome: props.nomeVaga, descricaovaga: props.descricaoVaga, salario: props.salario, telefone: props.telefone });
  }  

return(
    <View style={styles.card}>
      <View> 
        <Text style={styles.tituloCard}> {props.nomeVaga} </Text>
        <Text style={{display: 'none'}}> Salário: {props.salario} </Text>
        <Text style={styles.telefoneCard}> {props.telefone} </Text>
        <Text style={{display: 'none'}}> {props.descricaoVaga} </Text>
        <Button title="Detalhes" onPress={irDetalhes} color='#000'/>
      </View>
    </View>

  );


}

export default Card