import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
    titulo:{
      fontFamily: "sans-serif",
      fontSize: 25,
      fontWeight: "700",
      color: 'white',
      marginTop: 5,
      textAlign: 'center',
      backgroundColor: '#F5A700',
      padding: 20,
      borderRadius: 20,
      marginLeft: 20,
      marginRight: 20
    },
    container:{
      alignItems: 'center',
      marginTop: 48
    },
    imagem:{
    height: 30,
    width: 10,
    borderRadius: 20,
    justifyContent: 'center', 
    alignItems: 'center'
  }
});


export {styles}
