import { View, Text, Image } from 'react-native'

import {styles} from './styles'

function Header(props){
  return(
      <View style={styles.container}>
        <Text style={styles.titulo}>Conversor de {props.moeda}</Text>
        <Image source={ props.imagem } style={styles.imagem}/>
      </View>
  )
}

export default Header