import  React, { useState } from 'react'
import { View, Text, TextInput, Button, SafeAreaView, Image } from 'react-native'

import {styles} from './Styles'

import Input from '../../components/input/index'
import Botao from '../../components/botao/index'
import Header from '../../components/header/index'

function ConversorBitcoin(){

  const [valor, setValor] = useState(0)
  const [resultado, setResultado] = useState()

  function calcular(){

  let exibe;
    
  exibe = valor * 0.0000017 
  setResultado(exibe.toFixed(2))
   
  }

return(
    <SafeAreaView>

      <View style={styles.area}>
        
        <Header 
        moeda="Bitcoin 💴" 
        />

        <Input
          placeholder = 'Digite o valor para converter'
          funcao = {setValor}
          tipo = 'decimal-pad'
        /> 

        <Botao 
          titulo = 'Calcular'
          cor = '#FFB30F'
          funcao = {calcular}
        />


        <Text style={styles.resultado}>Resultado: {resultado}</Text>

        </View>
    </SafeAreaView>
  )

}

export default ConversorBitcoin