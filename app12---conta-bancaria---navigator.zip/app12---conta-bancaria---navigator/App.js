import {View} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

import ContaBancaria from './src/pages/ContaBancaria/index';
import Dados from './src/pages/DadosInformados/index';

const Stack = createStackNavigator();

function App(){

return(
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Contabancaria" component={ContaBancaria} 
        options={{ headerShown: false }} />
        <Stack.Screen name="Dados" component={Dados} />
      </Stack.Navigator>
    </NavigationContainer>

)

}

export default App;
