import { View, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import {styles} from '../ContaBancaria/styles'


export default function DadosInfo( {route}) {

 return (
   <View style={styles.areaDadosExibidos}>
    <View style={styles.dadosExibidos}>
          <Text style={ styles.tituloDados }>Dados Informados</Text>
          <Text>Nome: {route.params?.nome}</Text>
          <Text>Idade: {route.params?.idade}</Text>
          <Text>Sexo: {route.params?.sexo}</Text>
          <Text>Escolaridade: {route.params?.escolaridade}</Text>
          <Text>Limite: R$ {route.params?.limite.toFixed(2)}</Text>
          <Text>Brasileiro: {route.params?.brasileiro ? 'Sim' : 'Não'}</Text>
        </View>
      </View>
  );
}
