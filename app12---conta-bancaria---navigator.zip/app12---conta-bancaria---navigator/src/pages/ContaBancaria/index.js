import { Text, View, StyleSheet, TextInput, Switch, Button,Image } from 'react-native';
import {useState} from 'react';
import {Picker} from '@react-native-picker/picker';
import Slider from '@react-native-community/slider';
import { useNavigation } from '@react-navigation/native';


import imagemBanco from '../../../assets/gbank-retangulo.png'
import {styles} from './styles'


function ContaBancaria() {

  const navigation = useNavigation();

  const [nome, setNome] = useState('');
  const [idade, setIdade] = useState('');
  const [sexo, setSexo] = useState('');
  const [escolaridade, setEscolaridade] = useState('');
  const [limite, setLimite] = useState(0);
  const [brasileiro, setBrasileiro] = useState(false);
  const [exibeInfos, setExibeInfos] = useState(null);

  const irDados = () => {
    navigation.navigate('Dados', {nome, idade, sexo, escolaridade, limite, brasileiro})
  }

  return (
          <View style={styles.wrapContainer}>
          <Image source={ imagemBanco } style={styles.imagem}/>
            <Text style={styles.title}>Abertura de Contas</Text>
            <Text>Nome:
              <TextInput style={[styles.input, styles.inputNome]} placeholder="Digite seu nome completo" onChangeText={setNome}/>
            </Text>
            <Text>Idade:
              <TextInput style={styles.input} keyboardType="numeric" placeholder="Digite sua idade" onChangeText={setIdade}/>
            </Text>
            <Text>Sexo:
              <Picker style={styles.select}
                selectedValue={sexo}
                onValueChange={(itemValue, itemIndex) => setSexo(itemValue)}
              >
                <Picker.Item key={0} value="" label="Selecione" />
                <Picker.Item key={1} value="Feminino" label="Feminino" />
                <Picker.Item key={2} value="Masculino" label="Masculino" />
              </Picker>
            </Text>
            <Text>Escolaridade:
              <Picker style={styles.select}
                selectedValue={escolaridade}
                onValueChange={(itemValue, itemIndex) => setEscolaridade(itemValue)}
              >
                <Picker.Item key={0} value="" label="Selecione" />
                <Picker.Item key={1} value="Ensino Fundamental" label="Ensino Fundamental" />
                <Picker.Item key={2} value="Ensino Médio" label="Ensino Médio" />
                <Picker.Item key={3} value="Ensino Superior" label="Ensino Superior" />
              </Picker>
            </Text>
            <Text>Limite:</Text>
            <Slider
              minimumValue={100}
              maximumValue={30000000}
              onValueChange={(valorSelecionado) => setLimite(valorSelecionado)}
              value={limite}
            />
            <Text style={{textAlign: 'end', fontSize: 16, backrgroundColor: '#000'}}>
                R$ {limite.toFixed(2)}
            </Text>
            <View style={styles.wrapSwitch}>
              <Text>Brasileiro:</Text>
                <Switch
                  value={brasileiro}
                  onValueChange={ (valorSwitch) => setBrasileiro(valorSwitch) }
                  thumbColor= '#000'
                />
            </View>
            <Button title="Confirmar" onPress={irDados} color='#000'/>
            {exibeInfos}
          </View>
  )
}

export default ContaBancaria
