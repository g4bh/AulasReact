import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  wrapContainer: {
    padding: 30,
    backgroundColor: '#FEC619'
  },
  title: {
    alignSelf: 'center',
    fontSize: 18,
    fontWeight: 500,
    marginBottom: 15
  },
  input: {
    width: 112,
    height: 30,
    borderWidth: 1,
    borderRadius: 10,
    paddingLeft: 5,
    marginBottom: 10,
    marginLeft: 5,
    borderColor: '#000',
    backgroundColor: '#fff'
  },
  inputNome: {
    width: '80%'
  },
  select: {
    height: 35,
    borderRadius: 10,
    padding: 2,
    marginLeft: 5,
    marginBottom: 10,
    backgroundColor: '#fff'
  },
  wrapSwitch: {
    flexDirection: 'row',
    gap: 5,
    marginBottom: 15
  },
  imagem:{
    marginBottom: 30,
    borderRadius: 20,
    width: 300,
    height: 70,
    resizeMode: 'contain',
  },
  dadosExibidos: {
    marginTop: 10,
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 15
  },
  tituloDados:
  {
    fontWeight: 500, 
    marginBottom: 5,
    fontSize: 20
  },
  areaDadosExibidos:
  {
    padding: 30,
    backgroundColor: '#FEC619'
  }
});

export {styles}
