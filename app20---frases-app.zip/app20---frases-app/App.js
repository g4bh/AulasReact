import {View, Text} from 'react-native';

import Visualizador from './src/pages/Visualizador/Index';

function App(){

return (

    <Visualizador />
)

}

export default App;