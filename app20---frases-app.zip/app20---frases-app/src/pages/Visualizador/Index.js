import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Switch } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/FontAwesome6';
import {styles} from './Style'

export default function App() {
  const [dark, setDark] = useState(false);
  const [little, setLittle] = useState(false);

  useEffect(() => {
    const recuperarEfeitos = async () => {
      const tema = await AsyncStorage.getItem('tema');
      setDark(tema === 'dark');

      const tamanho = await AsyncStorage.getItem('tamanho');
      setLittle(tamanho === 'little');
    };

    recuperarEfeitos();
  }, []);

  const gravaTema = async () => {
    const novoTema = !dark ? 'dark' : 'light';
    setDark(!dark);
    await AsyncStorage.setItem('tema', novoTema);
  };

  const gravaTamanho = async () => {
    const novoTamanho = !little ? 'little' : 'normal';
    setLittle(!little);
    await AsyncStorage.setItem('tamanho', novoTamanho);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Frases motivadoras </Text>
      <Text style={styles.title}> Michael Scott </Text>
      <View style={styles.botoes}>
        <View style={{flexDirection: 'row'}}>
          <Icon name="sun" size={24} color="white" />
          <Switch style={styles.suit}
            value={dark}
            onValueChange={gravaTema}
            thumbColor='white'
        />
        <Icon name="moon" size={24} color="white" />
        </View>
          <View style={{flexDirection: 'row'}}>
          <Icon name="plus" size={24} color="white" />
          <Switch style={styles.suit}
            value={little}
            onValueChange={gravaTamanho}
            thumbColor='white'
          />
          <Icon name="minus" size={24} color="white" />
        </View>
      </View>
      <View style={[styles.wrapContent, dark && styles.darkBackground]}>
        <Text style={little && styles.littleText}>Eu preferiria ser temido ou amado? Fácil. Ambos. Quero que as pessoas tenham medo do quanto me amam.</Text>
        <Text style={little && styles.littleText}> - Michael Scott</Text>
      </View>
    </View>
  );
}
