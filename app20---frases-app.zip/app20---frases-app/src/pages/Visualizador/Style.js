import {StyleSheet} from 'react-native'

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    padding: 30,
    backgroundColor: '#832161'
  },
  title: {
    fontSize: 20,
    fontWeight: 800,
    marginBottom: 20,
    color: '#009688'
  },
  wrapContent: {
    padding: 20,
    height: 400,
    borderWidth: 2,
    borderRadius: 20,
    borderColor: '#ffff', 
  },
  darkBackground: {
    backgroundColor: '#ACADAE'
  },
  littleText: {
    fontSize: 10
  },
  suit:{
    marginLeft: 5,
    marginRight: 5
  },
  botoes: {
    flexDirection: 'row', 
    gap: 40, 
    marginBottom: 40,
    marginTop: 40
  }
});


export {styles}