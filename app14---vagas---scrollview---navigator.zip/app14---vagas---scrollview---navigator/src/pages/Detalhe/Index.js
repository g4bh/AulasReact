import {View, Text, Image} from 'react-native';
import {styles} from './Style';

export default function Detalhe( {route} ) {

const { nome, descricaovaga, salario, telefone } = route.params; 

  return (
    <View style={styles.areaDadosExibidos}>
    <View style={styles.dadosExibidos}>
          <Text style={ styles.tituloCard }>Dados - Vaga</Text>
          <Text style={styles.tituloCard}>{nome}</Text>
          <Text style={styles.descricaoCard}>{descricaovaga}</Text>
          <Text style={styles.precoCard}>{salario}</Text>
          <Text style={styles.descricaoCard}>{telefone}</Text>
        </View>
      </View>
  );
}